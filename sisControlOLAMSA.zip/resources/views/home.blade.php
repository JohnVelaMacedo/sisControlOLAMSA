@extends('layouts.master')

@section('content')
<div id="app">
    <h1>Cargando...</h1>
</div>
@endsection
